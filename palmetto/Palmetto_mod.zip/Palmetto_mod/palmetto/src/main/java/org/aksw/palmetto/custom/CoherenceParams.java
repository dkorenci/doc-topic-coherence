package org.aksw.palmetto.custom;

/**
 * Struct describing coherence measure.
  */
public class CoherenceParams {

    public String indexPath;
    public String type;
    public boolean standard;
    
    /** If 0 use boolean document frequency count, else use windows. */
    public int windowSize; 
    
    public CoherenceParams(String type, String index, boolean standard, int windowSize) {
        this.type = type; this.indexPath = index; 
        this.standard = standard; this.windowSize = windowSize;
    }
    
}
