/**
 * This file is part of Palmetto.
 *
 * Palmetto is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Palmetto is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Palmetto.  If not, see <http://www.gnu.org/licenses/>.
 */
package org.aksw.palmetto.calculations.direct;

import org.aksw.palmetto.data.SubsetProbabilities;

/**
 * This confirmation measure calculates Olssons coherence.
 * 
 * @author Michael Röder
 * 
 */
public class OlssonsConfirmationMeasure extends AbstractUndefinedResultHandlingConfirmationMeasure {

    public OlssonsConfirmationMeasure() {
        super();
    }

    public OlssonsConfirmationMeasure(double resultIfCalcUndefined) {
        super(resultIfCalcUndefined);
    }

    @Override
    public double[] calculateConfirmationValues(SubsetProbabilities subsetProbabilities) {
        int pos = 0;
        for (int i = 0; i < subsetProbabilities.segments.length; ++i) {
            pos += subsetProbabilities.conditions[i].length;
        }
        double values[] = new double[pos];

        double intersectionProbability, jointProbability;
        pos = 0;
        for (int i = 0; i < subsetProbabilities.segments.length; ++i) {
            for (int j = 0; j < subsetProbabilities.conditions[i].length; ++j) {
                intersectionProbability = subsetProbabilities.probabilities[subsetProbabilities.segments[i]
                        | subsetProbabilities.conditions[i][j]];
                jointProbability = determineJointProbability(subsetProbabilities.segments[i]
                        | subsetProbabilities.conditions[i][j], subsetProbabilities.probabilities);
                if (jointProbability > 0) {
                    values[pos] = intersectionProbability / jointProbability;
                } else {
                    values[pos] = resultIfCalcUndefined;
                }
                ++pos;
            }
        }
        return values;
    }

    private double determineJointProbability(int jointBits, double[] probabilities) {
        double jointProbability = 0;
        int inverseMask = ~jointBits;
        for (int i = 1; i <= jointBits; i++) {
            // if all bits of the current i are elements of the joint set
            if ((inverseMask & i) == 0) {
                // if the number of elements are even
                if ((Integer.bitCount(i) & 1) == 0) {
                    jointProbability -= probabilities[i];
                } else {
                    jointProbability += probabilities[i];
                }
            }
        }
        return jointProbability;
    }

    @Override
    public String getName() {
        return "m_o";
    }
}
