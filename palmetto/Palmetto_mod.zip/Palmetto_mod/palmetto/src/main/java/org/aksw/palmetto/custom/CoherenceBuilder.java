package org.aksw.palmetto.custom;

import java.io.IOException;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.logging.Level;
import org.aksw.palmetto.Coherence;
import org.aksw.palmetto.DirectConfirmationBasedCoherence;
import org.aksw.palmetto.VectorBasedCoherence;

import org.aksw.palmetto.aggregation.ArithmeticMean;
import org.aksw.palmetto.calculations.direct.FitelsonConfirmationMeasure;
import org.aksw.palmetto.calculations.direct.LogCondProbConfirmationMeasure;
import org.aksw.palmetto.calculations.direct.LogRatioConfirmationMeasure;
import org.aksw.palmetto.calculations.direct.NormalizedLogRatioConfirmationMeasure;
import org.aksw.palmetto.calculations.indirect.CosinusConfirmationMeasure;
import org.aksw.palmetto.corpus.CorpusAdapter;
import org.aksw.palmetto.corpus.WindowSupportingAdapter;
import org.aksw.palmetto.corpus.lucene.LuceneCorpusAdapter;
import org.aksw.palmetto.corpus.lucene.WindowSupportingLuceneCorpusAdapter;
import org.aksw.palmetto.io.SimpleWordSetReader;
import org.aksw.palmetto.prob.ProbabilityEstimator;
import org.aksw.palmetto.prob.bd.BooleanDocumentProbabilitySupplier;
import org.aksw.palmetto.prob.window.BooleanSlidingWindowFrequencyDeterminer;
import org.aksw.palmetto.prob.window.ContextWindowFrequencyDeterminer;
import org.aksw.palmetto.prob.window.WindowBasedFrequencyDeterminer;
import org.aksw.palmetto.prob.window.WindowBasedProbabilityEstimator;
import org.aksw.palmetto.subsets.OneOne;
import org.aksw.palmetto.subsets.OnePreceding;
import org.aksw.palmetto.subsets.OneSet;
import org.aksw.palmetto.vector.DirectConfirmationBasedVectorCreator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Build coherence calculators given build params. 
 * Modified version of the org.aksw.palmetto.Palmetto class.
 * 
 */
public class CoherenceBuilder {

    private static final Logger LOGGER = LoggerFactory.getLogger(CoherenceBuilder.class);

    private static final String USAGE = "palmetto.jar <index-directory> <coherence-name> <input-file>";

    public static final String DEFAULT_TEXT_INDEX_FIELD_NAME = "text";
    public static final String DEFAULT_DOCUMENT_LENGTH_INDEX_FIELD_NAME = "length";

    public static Coherence constructCoherence(CoherenceParams cpar) {
        if (cpar.standard) {
            CorpusAdapter corpusAdapter = getCorpusAdapter(cpar.type, cpar.indexPath);
            if (corpusAdapter == null) return null;            
            return getCoherenceStandard(cpar.type, corpusAdapter);               
        }
        else try {
            return getCoherenceParams(cpar);
        } catch (IOException ex) {
            return null;
        }
    }
    
    public static void main(String[] args) throws IOException {
        boolean old = false;
        if (old) {
            String[] measure = {"umass", "uci", "npmi", "c_a", "c_v", "c_p"};
            for (String m: measure) {
                String[] runParams = {
                    "/datafast/palmetto_indexes/wikipedia_uspoltok/windowed_documents",
                    m,
                    "input.txt"
                };
                System.out.println(m);
                run(runParams);
            }
        }
        else testCoherenceCreation();
    }
    
    public static void testCoherenceCreation() throws IOException {
        String windex = "/datafast/palmetto_indexes/wikipedia_uspoltok/windowed_documents";
        String bdindex = "/datafast/palmetto_indexes/wikipedia_uspoltok/boolean_documents/";
        String bpindex = "/datafast/palmetto_indexes/wikipedia_uspoltok/boolean_paragraphs/";
        CoherenceParams[] standardParams = {
            new CoherenceParams("umass", windex, true, 0),
            new CoherenceParams("uci", windex, true, 0),
            new CoherenceParams("npmi", windex, true, 0),
            new CoherenceParams("c_a", windex, true, 0),
            new CoherenceParams("c_v", windex, true, 0),
            new CoherenceParams("c_p", windex, true, 0),
        };
        CoherenceParams[] newParams = {
//            new CoherenceParams("umass", windex, false, 0),
//            new CoherenceParams("umass", bpindex, false, 0),
//            new CoherenceParams("umass", windex, false, 20),
//            new CoherenceParams("uci", windex, false, 0),
//            new CoherenceParams("uci", bpindex, false, 0),
//            new CoherenceParams("uci", windex, false, 20),
//            new CoherenceParams("npmi", windex, false, 0),
//            new CoherenceParams("npmi", bpindex, false, 0),
//            new CoherenceParams("npmi", windex, false, 20),
//            new CoherenceParams("c_a", windex, false, 5),
//            new CoherenceParams("c_a", windex, false, 10),
//            new CoherenceParams("c_a", windex, false, 50),
//            new CoherenceParams("c_v", windex, false, 0),
//            new CoherenceParams("c_v", bpindex, false, 0),
//            new CoherenceParams("c_v", windex, false, 20),
            new CoherenceParams("c_p", windex, false, 0),
            new CoherenceParams("c_p", bpindex, false, 0),
            new CoherenceParams("c_p", windex, false, 10),
            new CoherenceParams("c_p", windex, false, 20),
            new CoherenceParams("c_p", windex, false, 100),
        };
//        CoherenceParams[] params = standardParams;
        CoherenceParams[] params = newParams;
        String infile = "input.txt";
        for (CoherenceParams p: params) {
            Coherence coh = (Coherence)constructCoherence(p);
            runCoherence(coh, infile);
        }
    }
    
    public static void runCoherence(Coherence coh, String infile) {
        SimpleWordSetReader reader = new SimpleWordSetReader();
        String wordsets[][] = reader.readWordSets(infile);       
        double coherences[] = coh.calculateCoherences(wordsets);
        System.out.println(coh.getName());
        printCoherences(coherences, wordsets, System.out);
    }
    
    public static void run(String[] args) {
        if (args.length < 3) {
            LOGGER.error("Wrong number of arguments. Usage:\n" + USAGE);
            return;
        }
        String indexPath = args[0];
        String calcType = args[1].toLowerCase();
        String inputFile = args[2];

        CorpusAdapter corpusAdapter = getCorpusAdapter(calcType, indexPath);
        if (corpusAdapter == null) {
            return;
        }

        Coherence coherence = getCoherenceStandard(calcType, corpusAdapter);
        if (coherence == null) {
            return;
        }

        SimpleWordSetReader reader = new SimpleWordSetReader();
        String wordsets[][] = reader.readWordSets(inputFile);
        LOGGER.info("Read " + wordsets.length + " from file.");

        double coherences[] = coherence.calculateCoherences(wordsets);
        corpusAdapter.close();

        printCoherences(coherences, wordsets, System.out);
    }
    
    public static CorpusAdapter getCorpusAdapter(String calcType, String indexPath) {
        try {
            if ("umass".equals(calcType)) {
                return LuceneCorpusAdapter.create(indexPath, DEFAULT_TEXT_INDEX_FIELD_NAME);
            } else {
                return WindowSupportingLuceneCorpusAdapter.create(indexPath,
                        DEFAULT_TEXT_INDEX_FIELD_NAME, DEFAULT_DOCUMENT_LENGTH_INDEX_FIELD_NAME);
            }
        } catch (Exception e) {
            LOGGER.error("Couldn't open lucene index. Aborting.", e);
            return null;
        }
    }

    public static Coherence getCoherenceParams(CoherenceParams cpar) throws IOException {
        ProbabilityEstimator probEstim;
        WindowSupportingLuceneCorpusAdapter wadapter = null;
        CorpusAdapter adapter;
        if (cpar.windowSize == 0) {
            adapter = LuceneCorpusAdapter.create(cpar.indexPath, DEFAULT_TEXT_INDEX_FIELD_NAME);
            probEstim = BooleanDocumentProbabilitySupplier.create(adapter, "bd", true);
        }
        else {
            wadapter = WindowSupportingLuceneCorpusAdapter.create(cpar.indexPath,
                        DEFAULT_TEXT_INDEX_FIELD_NAME, DEFAULT_DOCUMENT_LENGTH_INDEX_FIELD_NAME);
            probEstim = getWindowBasedProbabilityEstimator(cpar.windowSize, wadapter);            
        }
                    
        if ("umass".equals(cpar.type)) {
            return new DirectConfirmationBasedCoherence(new OnePreceding(),
                    probEstim, new LogCondProbConfirmationMeasure(), new ArithmeticMean());
        }
        if ("uci".equals(cpar.type)) {
            return new DirectConfirmationBasedCoherence(
                    new OneOne(), probEstim, new LogRatioConfirmationMeasure(), new ArithmeticMean());
        }
        if ("npmi".equals(cpar.type)) {
            return new DirectConfirmationBasedCoherence(
                    new OneOne(), probEstim, new NormalizedLogRatioConfirmationMeasure(), new ArithmeticMean());
        }
        if ("c_a".equals(cpar.type)) {            
            WindowBasedProbabilityEstimator probEstimator = new WindowBasedProbabilityEstimator(
                    new ContextWindowFrequencyDeterminer(wadapter, cpar.windowSize));
            probEstimator.setMinFrequency(WindowBasedProbabilityEstimator.DEFAULT_MIN_FREQUENCY * cpar.windowSize);
            return new VectorBasedCoherence(
                    new OneOne(), new DirectConfirmationBasedVectorCreator(probEstimator,
                            new NormalizedLogRatioConfirmationMeasure()), new CosinusConfirmationMeasure(),
                    new ArithmeticMean());
        }
        if ("c_p".equals(cpar.type)) {
            return new DirectConfirmationBasedCoherence(
                    new OnePreceding(), probEstim,
                    new FitelsonConfirmationMeasure(), new ArithmeticMean());
        }
        if ("c_v".equals(cpar.type)) {
            return new VectorBasedCoherence(new OneSet(),
                    new DirectConfirmationBasedVectorCreator(probEstim,
                            new NormalizedLogRatioConfirmationMeasure()),
                    new CosinusConfirmationMeasure(), new ArithmeticMean());
        }
        StringBuilder msg = new StringBuilder();
        msg.append("Unknown calculation type \"");
        msg.append(cpar.type);
        msg.append("\". Supported types are:\nUMass\nUCI\nNPMI\nC_A\nC_P\nC_V\n\nAborting.");
        throw new IllegalArgumentException(msg.toString());
    }
    
    /**
     * Standard coherences from the paper, with fixed parameters. 
     */
    public static Coherence getCoherenceStandard(String calcType, CorpusAdapter corpusAdapter) {
        if ("umass".equals(calcType)) {
            return new DirectConfirmationBasedCoherence(new OnePreceding(),
                    BooleanDocumentProbabilitySupplier.create(corpusAdapter, "bd", true),
                    new LogCondProbConfirmationMeasure(), new ArithmeticMean());
        }

        if ("uci".equals(calcType)) {
            return new DirectConfirmationBasedCoherence(
                    new OneOne(), getWindowBasedProbabilityEstimator(10, (WindowSupportingAdapter) corpusAdapter),
                    new LogRatioConfirmationMeasure(), new ArithmeticMean());
        }

        if ("npmi".equals(calcType)) {
            return new DirectConfirmationBasedCoherence(
                    new OneOne(), getWindowBasedProbabilityEstimator(10, (WindowSupportingAdapter) corpusAdapter),
                    new NormalizedLogRatioConfirmationMeasure(), new ArithmeticMean());
        }

        if ("c_a".equals(calcType)) {
            int windowSize = 5;
            WindowBasedProbabilityEstimator probEstimator = new WindowBasedProbabilityEstimator(
                    new ContextWindowFrequencyDeterminer((WindowSupportingAdapter) corpusAdapter, windowSize));
            probEstimator.setMinFrequency(WindowBasedProbabilityEstimator.DEFAULT_MIN_FREQUENCY * windowSize);
            return new VectorBasedCoherence(
                    new OneOne(), new DirectConfirmationBasedVectorCreator(probEstimator,
                            new NormalizedLogRatioConfirmationMeasure()), new CosinusConfirmationMeasure(),
                    new ArithmeticMean());
        }

        if ("c_p".equals(calcType)) {
            return new DirectConfirmationBasedCoherence(
                    new OnePreceding(),
                    getWindowBasedProbabilityEstimator(70, (WindowSupportingAdapter) corpusAdapter),
                    new FitelsonConfirmationMeasure(), new ArithmeticMean());
        }

        if ("c_v".equals(calcType)) {
            return new VectorBasedCoherence(new OneSet(),
                    new DirectConfirmationBasedVectorCreator(
                            getWindowBasedProbabilityEstimator(110, (WindowSupportingAdapter) corpusAdapter),
                            new NormalizedLogRatioConfirmationMeasure()),
                    new CosinusConfirmationMeasure(), new ArithmeticMean());
        }

        StringBuilder msg = new StringBuilder();
        msg.append("Unknown calculation type \"");
        msg.append(calcType);
        msg.append("\". Supported types are:\nUMass\nUCI\nNPMI\nC_A\nC_P\nC_V\n\nAborting.");
        LOGGER.error(msg.toString());
        return null;
    }

    public static WindowBasedProbabilityEstimator getWindowBasedProbabilityEstimator(int windowSize,
            WindowSupportingAdapter corpusAdapter) {
        WindowBasedProbabilityEstimator probEstimator = new WindowBasedProbabilityEstimator(
                new BooleanSlidingWindowFrequencyDeterminer(
                        corpusAdapter, windowSize));
        probEstimator.setMinFrequency(WindowBasedProbabilityEstimator.DEFAULT_MIN_FREQUENCY * windowSize);
        return probEstimator;
    }

    public static void printCoherences(double[] coherences, String[][] wordsets, PrintStream out) {
        for (int i = 0; i < wordsets.length; i++) {
            out.format("%5d\t%3.5f\t%s%n", new Object[] { i, coherences[i], Arrays.toString(wordsets[i]) });
        }
    }
}
